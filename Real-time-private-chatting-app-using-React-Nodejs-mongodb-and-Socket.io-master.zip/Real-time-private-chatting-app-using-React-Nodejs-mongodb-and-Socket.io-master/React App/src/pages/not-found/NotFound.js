
import React, { Component } from 'react';
import './NotFound.css';

class NotFound extends Component {
  render() {
    return (
      <div className="App">
        NotFound Component
      </div>
    );
  }
}

export default NotFound;
